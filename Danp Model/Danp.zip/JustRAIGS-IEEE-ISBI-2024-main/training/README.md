1. Run 00_prepare.ipynb
2. Run 01_split.ipynb
3. Run train.py [configuration file name]

Configuration file examples: ../src/weights