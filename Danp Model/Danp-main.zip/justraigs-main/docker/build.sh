docker build --tag justraigs_data_centric .

