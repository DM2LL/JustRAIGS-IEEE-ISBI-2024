# JustRAIGS
Justified Referral in AI Glaucoma Screening challenge ([JustRAIGS](https://justraigs.grand-challenge.org/)) on IEEE ISBI 2024

## Citation
```bash

```
